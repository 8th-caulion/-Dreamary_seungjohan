from django.contrib import admin
from django.urls import path
import map.views

urlpatterns = [
    path('', map.views.map, name="map"),
    
]
