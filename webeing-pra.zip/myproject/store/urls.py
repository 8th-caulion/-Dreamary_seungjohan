from django.contrib import admin
from django.urls import path
import store.views

urlpatterns = [
    path('', store.views.store, name="store"),
    
]
